class Player
{
constructor()
{
this.angle=z*4;
this.x=45;
this.y=45;
this.speed=3;
this.life=100;
this.direction;
this.isTakingDamage=false;
this. isTurning=false;
this.isMoving=false;
this.tileX=0;
this.tileY=0;
}
}


///////////////////////////////////

